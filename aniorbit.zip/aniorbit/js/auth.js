/* AniOrbit — demo authentication
   This stores accounts in the browser's localStorage so the site has a
   working login/signup flow with no backend to set up. It is a starting
   point, not real security: passwords sit in plain text in the browser
   and accounts don't sync between devices. Before real users sign up,
   swap this file for a proper auth provider (Supabase, Firebase Auth,
   Auth0, or your own API) and keep the same function names so the rest
   of the site doesn't need to change. */

const USERS_KEY = 'aniorbit_users';
const SESSION_KEY = 'aniorbit_session';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function signup(username, password) {
  username = username.trim();
  if (!username || !password) return { ok: false, error: 'Enter a username and password.' };
  const users = getUsers();
  if (users[username]) return { ok: false, error: 'That username is already taken.' };
  users[username] = { password };
  saveUsers(users);
  localStorage.setItem(SESSION_KEY, username);
  return { ok: true };
}

function login(username, password) {
  username = username.trim();
  const users = getUsers();
  if (!users[username] || users[username].password !== password) {
    return { ok: false, error: 'Incorrect username or password.' };
  }
  localStorage.setItem(SESSION_KEY, username);
  return { ok: true };
}

function logout() {
  localStorage.removeItem(SESSION_KEY);
  window.location.href = 'index.html';
}

function currentUser() {
  return localStorage.getItem(SESSION_KEY);
}

function renderAuthState() {
  const slot = document.getElementById('auth-slot');
  if (!slot) return;
  const user = currentUser();
  if (user) {
    slot.innerHTML = `<span class="nav-user">${user}</span><button id="logout-btn" class="btn btn-ghost">Log out</button>`;
    document.getElementById('logout-btn').addEventListener('click', logout);
  } else {
    slot.innerHTML = `<a href="login.html" class="btn btn-ghost">Log in</a><a href="signup.html" class="btn btn-primary">Sign up</a>`;
  }
}

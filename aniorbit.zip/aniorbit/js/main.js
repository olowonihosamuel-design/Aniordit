/* AniOrbit — shared page behavior */

function titleOf(media) {
  return media.title.english || media.title.romaji || media.title.native;
}

function stripHtml(text) {
  return (text || '').replace(/<[^>]+>/g, '');
}

function animeCard(media) {
  const card = document.createElement('a');
  card.className = 'card';
  card.href = `anime.html?id=${media.id}`;
  const score = media.averageScore ? `<span class="card-score">${(media.averageScore / 10).toFixed(1)}</span>` : '';
  card.innerHTML = `
    <div class="card-poster" style="background-image:url('${media.coverImage.large}')">${score}</div>
    <p class="card-title">${titleOf(media)}</p>
  `;
  return card;
}

async function renderShelf(sectionId, fetcher) {
  const section = document.getElementById(sectionId);
  if (!section) return;
  const track = section.querySelector('.shelf-track');
  const items = await fetcher();
  track.innerHTML = '';
  if (!items.length) {
    track.innerHTML = '<p class="shelf-empty">Couldn\u2019t load this row right now &mdash; check your connection and refresh.</p>';
    return;
  }
  items.forEach(item => track.appendChild(animeCard(item)));
}

async function renderHero() {
  const hero = document.getElementById('hero');
  if (!hero) return;
  const items = await fetchTrending(5);
  if (!items.length) return;
  const pick = items[Math.floor(Math.random() * items.length)];
  hero.style.backgroundImage = `linear-gradient(180deg, rgba(11,11,20,0.15) 0%, rgba(11,11,20,0.65) 55%, var(--void) 100%), url('${pick.bannerImage || pick.coverImage.large}')`;
  document.getElementById('hero-title').textContent = titleOf(pick);
  document.getElementById('hero-desc').textContent = stripHtml(pick.description).slice(0, 200) + '\u2026';
  const genreWrap = document.getElementById('hero-genres');
  genreWrap.innerHTML = '';
  pick.genres.slice(0, 4).forEach(g => {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = g;
    genreWrap.appendChild(chip);
  });
  document.getElementById('hero-link').href = `anime.html?id=${pick.id}`;
}

function setupSearchBar() {
  const form = document.getElementById('nav-search-form');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const q = form.querySelector('input').value.trim();
    if (q) window.location.href = `search.html?q=${encodeURIComponent(q)}`;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setupSearchBar();
  renderAuthState();
});

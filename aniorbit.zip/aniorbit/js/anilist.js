/* AniOrbit — AniList API layer
   AniList's public GraphQL API needs no key and allows browser requests.
   Docs: https://docs.anilist.co */

const ANILIST_API = 'https://graphql.anilist.co';

async function anilistQuery(query, variables = {}) {
  try {
    const res = await fetch(ANILIST_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ query, variables })
    });
    const json = await res.json();
    if (json.errors) {
      console.error('AniList error:', json.errors[0].message);
      return null;
    }
    return json.data;
  } catch (err) {
    console.error('AniList request failed:', err);
    return null;
  }
}

const MEDIA_FIELDS = `
  id
  title { romaji english native }
  coverImage { large color }
  bannerImage
  averageScore
  genres
  format
  episodes
  status
  season
  seasonYear
  countryOfOrigin
  description(asHtml: false)
`;

function fetchTrending(perPage = 14) {
  const query = `query ($perPage: Int) {
    Page(perPage: $perPage) {
      media(sort: TRENDING_DESC, type: ANIME) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { perPage }).then(d => d?.Page?.media ?? []);
}

function fetchUpcoming(perPage = 14) {
  const query = `query ($perPage: Int) {
    Page(perPage: $perPage) {
      media(sort: POPULARITY_DESC, type: ANIME, status: NOT_YET_RELEASED) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { perPage }).then(d => d?.Page?.media ?? []);
}

function fetchByGenre(genre, perPage = 14) {
  const query = `query ($perPage: Int, $genre: String) {
    Page(perPage: $perPage) {
      media(sort: POPULARITY_DESC, type: ANIME, genre: $genre) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { perPage, genre }).then(d => d?.Page?.media ?? []);
}

function fetchByCountry(country, perPage = 8) {
  const query = `query ($perPage: Int, $country: CountryCode) {
    Page(perPage: $perPage) {
      media(sort: POPULARITY_DESC, type: ANIME, countryOfOrigin: $country) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { perPage, country }).then(d => d?.Page?.media ?? []);
}

async function fetchKoreanChinese(perPage = 8) {
  const [kr, cn] = await Promise.all([fetchByCountry('KR', perPage), fetchByCountry('CN', perPage)]);
  return [...kr, ...cn];
}

function searchAnime(term, perPage = 24) {
  const query = `query ($perPage: Int, $search: String) {
    Page(perPage: $perPage) {
      media(search: $search, type: ANIME) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { perPage, search: term }).then(d => d?.Page?.media ?? []);
}

function fetchAlphabeticalPage(page = 1, perPage = 48) {
  const query = `query ($page: Int, $perPage: Int) {
    Page(page: $page, perPage: $perPage) {
      pageInfo { hasNextPage }
      media(sort: TITLE_ROMAJI, type: ANIME) { ${MEDIA_FIELDS} }
    }
  }`;
  return anilistQuery(query, { page, perPage }).then(d => d?.Page ?? { media: [], pageInfo: {} });
}

function fetchById(id) {
  const query = `query ($id: Int) {
    Media(id: $id, type: ANIME) { ${MEDIA_FIELDS} }
  }`;
  return anilistQuery(query, { id: Number(id) }).then(d => d?.Media ?? null);
}

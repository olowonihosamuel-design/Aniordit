# AniOrbit

An anime discovery site pulling live data from [AniList](https://anilist.co)'s public GraphQL API. Static HTML/CSS/JS, no build step, no backend required.

## What's included

- `index.html` — home page: hero spotlight + shelves for Trending, Upcoming, Action, Romance, Adventure, Comedy, Fantasy, Sci-Fi, and Korean & Chinese animation
- `search.html` — search by title (English, romaji or native)
- `browse.html` — A–Z browse
- `anime.html` — detail page per title, with **Watch** and **Download** sections left as placeholders for you to fill in with your own links or embeds
- `login.html` / `signup.html` — working login/signup UI
- `css/style.css`, `js/anilist.js`, `js/auth.js`, `js/main.js`

## Two things to know before going live

1. **Login/signup is a demo.** Accounts are stored in the visitor's own browser (`localStorage`), not a real database — so an account made on one device won't exist on another, and this isn't secure enough for real user data. It's there so the site *works* end to end; swap `js/auth.js` for a real provider (Supabase, Firebase Auth, or your own API) when you're ready, keeping the same function names (`login`, `signup`, `logout`, `currentUser`) so nothing else needs to change.
2. **Watch/Download links are empty on purpose** — add your own embed code or links inside the `link-slot` blocks in `anime.html`.

## Preview locally

Just open `index.html` in a browser — no server needed, since it's pure static files talking to AniList's API directly.

## Deploy to Vercel (via GitHub)

1. **Create a GitHub repo** and add these files to it (via the GitHub app/website, GitHub Desktop, or `git push` from a computer).
2. **Go to vercel.com** and sign in with your GitHub account.
3. Click **Add New → Project**, then select the repo.
4. Framework preset: choose **Other** (this is plain static HTML, no build command needed).
5. Click **Deploy**. Vercel gives you a live `.vercel.app` URL within a minute.
6. From then on, every push to the repo's main branch automatically redeploys the site — no manual upload step.
